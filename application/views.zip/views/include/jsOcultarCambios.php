<script type="text/javascript" src="<?php echo base_url().'/vendor/js/jsOcultarCambios.js';?>"></script>

