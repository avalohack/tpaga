<script type="text/javascript" src="<?php echo base_url().'/vendor/js/ajax.js';?>"></script>

